﻿namespace Calculator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lblRez = new System.Windows.Forms.Label();
            this.trm1 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnIn = new System.Windows.Forms.Button();
            this.btnSc = new System.Windows.Forms.Button();
            this.btnIm = new System.Windows.Forms.Button();
            this.btnRes = new System.Windows.Forms.Button();
            this.btnAd = new System.Windows.Forms.Button();
            this.btnEg = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRez
            // 
            this.lblRez.BackColor = System.Drawing.SystemColors.ControlLightLight;
            resources.ApplyResources(this.lblRez, "lblRez");
            this.lblRez.Name = "lblRez";
            // 
            // trm1
            // 
            resources.ApplyResources(this.trm1, "trm1");
            this.trm1.Name = "trm1";
            // 
            // btnAdd
            // 
            resources.ApplyResources(this.btnAdd, "btnAdd");
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnIn
            // 
            resources.ApplyResources(this.btnIn, "btnIn");
            this.btnIn.Name = "btnIn";
            this.btnIn.UseVisualStyleBackColor = true;
            this.btnIn.Click += new System.EventHandler(this.btnIn_Click);
            // 
            // btnSc
            // 
            resources.ApplyResources(this.btnSc, "btnSc");
            this.btnSc.Name = "btnSc";
            this.btnSc.UseVisualStyleBackColor = true;
            this.btnSc.Click += new System.EventHandler(this.btnSc_Click);
            // 
            // btnIm
            // 
            resources.ApplyResources(this.btnIm, "btnIm");
            this.btnIm.Name = "btnIm";
            this.btnIm.UseVisualStyleBackColor = true;
            this.btnIm.Click += new System.EventHandler(this.btnIm_Click);
            // 
            // btnRes
            // 
            resources.ApplyResources(this.btnRes, "btnRes");
            this.btnRes.Name = "btnRes";
            this.btnRes.UseVisualStyleBackColor = true;
            this.btnRes.Click += new System.EventHandler(this.btnRes_Click);
            // 
            // btnAd
            // 
            resources.ApplyResources(this.btnAd, "btnAd");
            this.btnAd.Name = "btnAd";
            this.btnAd.UseVisualStyleBackColor = true;
            this.btnAd.Click += new System.EventHandler(this.btnAd_Click);
            // 
            // btnEg
            // 
            resources.ApplyResources(this.btnEg, "btnEg");
            this.btnEg.Name = "btnEg";
            this.btnEg.UseVisualStyleBackColor = true;
            this.btnEg.Click += new System.EventHandler(this.btnEg_Click);
            // 
            // frmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Controls.Add(this.btnEg);
            this.Controls.Add(this.btnAd);
            this.Controls.Add(this.btnRes);
            this.Controls.Add(this.btnIm);
            this.Controls.Add(this.btnSc);
            this.Controls.Add(this.btnIn);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.trm1);
            this.Controls.Add(this.lblRez);
            this.Name = "frmMain";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRez;
        private System.Windows.Forms.TextBox trm1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnIn;
        private System.Windows.Forms.Button btnSc;
        private System.Windows.Forms.Button btnIm;
        private System.Windows.Forms.Button btnRes;
        private System.Windows.Forms.Button btnAd;
        private System.Windows.Forms.Button btnEg;
    }
}

