﻿namespace Calculator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRez = new System.Windows.Forms.Label();
            this.trm1 = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnIn = new System.Windows.Forms.Button();
            this.btnSc = new System.Windows.Forms.Button();
            this.btnIm = new System.Windows.Forms.Button();
            this.btnRes = new System.Windows.Forms.Button();
            this.btnAd = new System.Windows.Forms.Button();
            this.btnEg = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblRez
            // 
            this.lblRez.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblRez.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblRez.Location = new System.Drawing.Point(108, -3);
            this.lblRez.Name = "lblRez";
            this.lblRez.Size = new System.Drawing.Size(133, 87);
            this.lblRez.TabIndex = 0;
            this.lblRez.Text = "Result";
            this.lblRez.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // trm1
            // 
            this.trm1.Location = new System.Drawing.Point(122, 107);
            this.trm1.Name = "trm1";
            this.trm1.Size = new System.Drawing.Size(100, 20);
            this.trm1.TabIndex = 3;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(31, 107);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Add Value";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnIn
            // 
            this.btnIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIn.Location = new System.Drawing.Point(122, 174);
            this.btnIn.Name = "btnIn";
            this.btnIn.Size = new System.Drawing.Size(33, 35);
            this.btnIn.TabIndex = 7;
            this.btnIn.Text = "x";
            this.btnIn.UseVisualStyleBackColor = true;
            // 
            // btnSc
            // 
            this.btnSc.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSc.Location = new System.Drawing.Point(188, 133);
            this.btnSc.Name = "btnSc";
            this.btnSc.Size = new System.Drawing.Size(34, 35);
            this.btnSc.TabIndex = 8;
            this.btnSc.Text = "-";
            this.btnSc.UseVisualStyleBackColor = true;
            // 
            // btnIm
            // 
            this.btnIm.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnIm.Location = new System.Drawing.Point(188, 177);
            this.btnIm.Name = "btnIm";
            this.btnIm.Size = new System.Drawing.Size(34, 32);
            this.btnIm.TabIndex = 10;
            this.btnIm.Text = "÷";
            this.btnIm.UseVisualStyleBackColor = true;
            // 
            // btnRes
            // 
            this.btnRes.Location = new System.Drawing.Point(247, 162);
            this.btnRes.Name = "btnRes";
            this.btnRes.Size = new System.Drawing.Size(75, 23);
            this.btnRes.TabIndex = 11;
            this.btnRes.Text = "Clear";
            this.btnRes.UseVisualStyleBackColor = true;
            // 
            // btnAd
            // 
            this.btnAd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnAd.Location = new System.Drawing.Point(123, 133);
            this.btnAd.Name = "btnAd";
            this.btnAd.Size = new System.Drawing.Size(32, 35);
            this.btnAd.TabIndex = 12;
            this.btnAd.Text = "+";
            this.btnAd.UseVisualStyleBackColor = true;
            this.btnAd.Click += new System.EventHandler(this.btnAd_Click);
            // 
            // btnEg
            // 
            this.btnEg.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnEg.Location = new System.Drawing.Point(42, 21);
            this.btnEg.Name = "btnEg";
            this.btnEg.Size = new System.Drawing.Size(60, 51);
            this.btnEg.TabIndex = 13;
            this.btnEg.Text = "=";
            this.btnEg.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEg.UseVisualStyleBackColor = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(351, 222);
            this.Controls.Add(this.btnEg);
            this.Controls.Add(this.btnAd);
            this.Controls.Add(this.btnRes);
            this.Controls.Add(this.btnIm);
            this.Controls.Add(this.btnSc);
            this.Controls.Add(this.btnIn);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.trm1);
            this.Controls.Add(this.lblRez);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRez;
        private System.Windows.Forms.TextBox trm1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnIn;
        private System.Windows.Forms.Button btnSc;
        private System.Windows.Forms.Button btnIm;
        private System.Windows.Forms.Button btnRes;
        private System.Windows.Forms.Button btnAd;
        private System.Windows.Forms.Button btnEg;
    }
}

