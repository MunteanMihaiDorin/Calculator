﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmMain : Form
    {
        double x, rez = 0;
        public frmMain()
        {
            InitializeComponent();
          /*  btnAd.Enabled = false;
            btnSc.Enabled = false;
            btnIm.Enabled = false;
            btnIn.Enabled = false;
            btnRes.Enabled = false;
            btnEg.Enabled = false;*/
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            x = int.Parse(trm1.Text);
        }

        private void btnAd_Click(object sender, EventArgs e)
        {
            rez = rez + x;
        }

    }
}
