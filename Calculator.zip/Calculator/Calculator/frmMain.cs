﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class frmMain : Form
    {
        public void btnoff()
        {
            btnAd.Enabled = false;
            btnSc.Enabled = false;
            btnIm.Enabled = false;
            btnIn.Enabled = false;
            btnRes.Enabled = false;
            btnEg.Enabled = false;
        }
        public void btnon()
        {
            btnAd.Enabled = true;
            btnSc.Enabled = true;
            btnIm.Enabled = true;
            btnIn.Enabled = true;
            btnRes.Enabled = true;
            btnEg.Enabled = true;
        }
        public void addv()
        {
            btnAdd.Enabled = true;
            trm1.Enabled = true;
        }
        double x, rez = 0,rezant=0,xant;
        int cont = 0;
        public frmMain()
        {
            InitializeComponent();
          btnoff();
        }

        private void btnIn_Click(object sender, EventArgs e)
        {
            btnoff();
            rez = rez * x;
            addv();
        }

        private void btnIm_Click(object sender, EventArgs e)
        {
            btnoff();
            rez = rez / x;
            addv();
        }

        private void btnEg_Click(object sender, EventArgs e)
        {
            lblRez.Text = rez.ToString();
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            rez = 0;
            x = 0;
            trm1.Clear();
            lblRez.Text = "Rezultat";
            btnoff();
            addv();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            cont++;
            if (trm1.Text != "")
            {
                x = int.Parse(trm1.Text);
                btnon();
                btnAdd.Enabled = false;
                trm1.Enabled = false;
            }
            if(cont==1)
            {
                rez = x;
              //  fx = x;
            }
        }

        private void btnAd_Click(object sender, EventArgs e)
        {
            btnoff();
            rez = rez + x;
            addv();
        }
        private void btnSc_Click(object sender, EventArgs e)
        {
            btnoff();
            rez = rez - x;
            addv();
        }

    }
}
